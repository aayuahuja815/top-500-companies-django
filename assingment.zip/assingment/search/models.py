from django.db import models
from django.urls import reverse



class Job(models.Model):
    company_link = models.CharField(max_length=500)

class Resume(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email = models.EmailField(max_length=100)
    contact = models.CharField(max_length=10)
    workexperiance = models.CharField(max_length=100, default='Null')
    skill = models.CharField(max_length=100)
    projects = models.CharField(max_length=100, default='Null')
    internships = models.CharField(max_length=100, default='Null')


    def __str__(self):
        return self.first_name+' '+self.last_name


    def get_absolute_url(self):
        return reverse('search:index')




