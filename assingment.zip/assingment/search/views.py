from django.views import generic
from django.views.generic.edit import CreateView,UpdateView,DeleteView
from django.urls import reverse_lazy
from django.shortcuts import render,redirect
from django.contrib.auth import authenticate, login
from django.views.generic import View
from .forms import UserForm
from django.shortcuts import render
from django.http import HttpResponse
from . models import *
from django.template import loader
from .models import Job

import bs4
import requests
def index(request):
    html = ''' 
    <html>
    <head>
    <meta charset="UTF-8">
    <link rel = "stylesheet" href = "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src = "https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src = "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    </head>
    <body style="background-color:rgb(225,225,128);">
    <nav class="navbar navbar-inverse">
        <div class="container-fluid">

            <!-- navbar -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#topNavBar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand " href="/search/">jobs</a>
            </div>

            <div class="collapse navbar-collapse" id="topNavBar">

                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="/search/">
                            <span class="glyphicon glyphicon-certificate" aria-hidden="true"></span>&nbsp; Jobs
                        </a>
                    </li>
                </ul>


                <ul class="nav navbar-nav navbar-right">
                    <li class="">
                        <a href="/search/register/">
                            <span class=".glyphicon glyphicon-log-in" aria-hidden="true"></span>&nbsp; Register
                        </a>
                    </li>
                    <li class="">
                        <a href="/search/resume/">
                            <span class="glyphicon glyphicon-plus" aria-hidden="true"></span>&nbsp;Resume
                        </a>
                    </li>
                    <li class="">
                        <a href="#">
                            <span class="glyphicon glyphicon-off" aria-hidden="true"></span>&nbsp; Logout
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <h1> <center><font color="blue" face="Algerian">TOP 500 COMPANIES, DON'T FORGET TO APPLY </font></center> </h1>
    <h5><u><center><i> Click the below links to visit the company's official website </i></center></u><h5>
    <br><br>
    '''

    url = "https://www.zyxware.com/articles/4344/list-of-fortune-500-companies-and-their-websites"
    data = requests.get(url)
    soup = bs4.BeautifulSoup(data.text, 'html.parser')
    #print(soup.prettify())
    #i = 1
    #for links in soup.find('table').find_all('a'):
    #    link = links.get('href')
    #    t = soup.find('table').find('tr').find_all('td')
    #    if link[0:1] != '/' and link[0:1] != '#':
    #        html += str(i) + '<a href= "'+link+'">' + str(t) + '</a> <br>'
    #        i = i + 1
    #    if i > 500:
    #        break
    #return HttpResponse(html)
    i=1
    for comp in soup.find('table').find_all('td'):
        html += '   '+'<h4><center>' + str(comp) + '</center></h4>'
        i = i+1
        if i > 1500:
            break
    html += '</body></html>'
    return HttpResponse(html)


class UserFormView(View):
    form_class = UserForm
    template_name = 'search/registration_form.html'

    # Display blank form
    def get(self,request):
        form = self.form_class(None)
        return render(request,self.template_name,{'form':form})

    #process form data
    def post(self,request):
        form = self.form_class(request.POST)
        if form.is_valid():
            user = form.save(commit=False)

            #cleaned normalize data
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user.set_password(password)
            user.save()

            #return user object if all credential are correct

            user = authenticate(username=username, password=password)
            if user is not None:
                if user.is_active:
                    login(request, user)
                    return redirect('search:index')


        return render(request, self.template_name, {'form':form})


class ResumeCreate(CreateView):
    model = Resume
    fields = ['first_name', 'last_name', 'email', 'contact', 'workexperiance', 'skill', 'projects', 'internships']
