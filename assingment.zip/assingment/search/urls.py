from django.contrib import admin
from django.conf.urls import url,include
from . import views

app_name = 'search'
urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^register/$', views.UserFormView.as_view(), name='register'),
    url(r'^resume/$', views.ResumeCreate.as_view(), name='resume_create'),
]
